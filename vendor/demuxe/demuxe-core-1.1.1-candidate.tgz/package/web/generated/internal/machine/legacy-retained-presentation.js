export function initialLegacyRetainedPresentation() { return Object.freeze({ preroll: false, epoch: 0, generation: -1, minGeneration: -1, minPts: -Infinity, selectedSerial: 0, closed: false, serial: 0, frames: Object.freeze([]), held: null, pending: Object.freeze([]), drawing: null, position: null, received: 0, drawn: 0, redraws: 0, dropped: 0, peakRetained: 0, peakPending: 0, missing: 0 }); }
const empty = Object.freeze([]);
export function legacyRetainedNeedsPump(state) { return state.frames.length + (state.held ? 1 : 0) >= 16; }
export function legacyRetainedRequestCurrent(state, id, epoch) { return !state.closed && state.epoch === epoch && state.pending.some(request => request.id === id); }
export function transitionLegacyRetainedPresentation(state, input) {
    const result = (next = state, extra = {}) => Object.freeze({ state: next, accepted: true, close: empty, cancel: empty, ...extra });
    const patch = (value) => Object.freeze({ ...state, ...value });
    const clear = (next, closed, minPts, minGeneration) => Object.freeze({ ...next, epoch: Math.min(Number.MAX_SAFE_INTEGER, next.epoch + 1), closed: closed || next.epoch >= Number.MAX_SAFE_INTEGER, minPts, minGeneration, frames: Object.freeze([]), held: null, pending: Object.freeze([]), drawing: null, position: null, selectedSerial: 0 });
    const ids = (next) => Object.freeze([...next.frames.map(f => f.id), ...next.held ? [next.held.id] : []]);
    if (input.type === 'reset')
        return result(Object.freeze({ ...clear(state, !!input.closed, input.target === undefined ? -Infinity : input.target * 1e6 - 150000, state.generation + 1), preroll: !!input.preroll }), { close: ids(state), cancel: Object.freeze(state.pending.map(r => r.id)), ...state.epoch >= Number.MAX_SAFE_INTEGER ? { error: 'Retained epoch exhausted' } : {} });
    if (input.type === 'receive') {
        let next = patch({ received: state.received + 1 }), close = empty, cancel = empty;
        const discard = (error) => result(Object.freeze({ ...next, dropped: next.dropped + 1 }), { discard: true, close, cancel, ...error ? { error } : {} });
        if (!Number.isFinite(input.pts) || !Number.isSafeInteger(input.generation))
            return discard('Invalid retained frame metadata');
        const key = Math.round(input.pts);
        if (input.pts < state.minPts && !state.pending.some(r => r.key === key) || input.generation < state.minGeneration || state.closed)
            return discard();
        if (input.generation !== state.generation) {
            // Before the first frame (including after an explicit source/seek reset),
            // native selection can arrive first. Its pending requests belong to this
            // presentation epoch; observing the expected generation must not erase them.
            if (state.generation === -1 || state.minGeneration > state.generation)
                next = Object.freeze({ ...next, generation: input.generation, minGeneration: input.generation });
            else {
                close = ids(state);
                cancel = Object.freeze(state.pending.map(r => r.id));
                next = Object.freeze({ ...clear(next, false, state.minPts, input.generation), generation: input.generation });
                if (next.closed)
                    return discard('Retained epoch exhausted');
            }
        }
        if (input.pendingTarget !== null && input.pts / 1e6 < input.pendingTarget - .15)
            return discard();
        if (next.frames.some(frame => frame.key === key))
            return discard('Duplicate retained frame timestamp');
        if (legacyRetainedNeedsPump(next)) {
            // Back-step decodes from an earlier keyframe without presenting preroll.
            // Retain a bounded tail until mpv selects the adjacent frame.
            const oldest = next.preroll ? next.frames.find(frame => !next.pending.some(r => r.key === frame.key)) : undefined;
            if (!oldest)
                return discard('Retained frame bound exceeded');
            close = Object.freeze([...close, oldest.id]);
            next = Object.freeze({ ...next, frames: Object.freeze(next.frames.filter(frame => frame !== oldest)) });
        }
        if (!Number.isSafeInteger(next.serial + 1))
            return discard('Retained identity exhausted');
        const frame = Object.freeze({ id: next.serial + 1, key }), frames = Object.freeze([...next.frames, frame]);
        return result(Object.freeze({ ...next, serial: frame.id, frames, peakRetained: Math.max(next.peakRetained, frames.length + (next.held ? 1 : 0)) }), { close, cancel, accept: frame.id });
    }
    if (state.closed)
        return result(state, { accepted: false });
    if (input.type === 'select') {
        if (!Number.isSafeInteger(input.serial) || !Number.isFinite(input.key) || !Number.isFinite(input.now) || !Number.isFinite(input.delay))
            return result(state, { accepted: false, error: 'Invalid retained selection' });
        if (input.serial === state.selectedSerial)
            return result(state, { accepted: false });
        const minPts = Math.max(state.minPts, input.key), old = state.frames.filter(frame => frame.key < minPts && !state.pending.some(r => r.key === frame.key)), frames = Object.freeze(state.frames.filter(frame => !old.includes(frame))), close = Object.freeze(old.map(frame => frame.id));
        const next = patch({ preroll: false, minPts, selectedSerial: input.serial, frames });
        if (input.redraw && state.held?.key === input.key) {
            if (!Number.isSafeInteger(state.serial + 1))
                return result(next, { close, error: 'Retained identity exhausted' });
            const id = state.serial + 1;
            return result(Object.freeze({ ...next, serial: id, drawing: Object.freeze({ id, frame: state.held.id, redraw: true }) }), { close, redraw: state.held.id, drawing: id });
        }
        if (input.key < 0 || state.pending.some(request => request.key === input.key))
            return result(next, { close, accepted: false });
        if (state.pending.length >= 8)
            return result(next, { close, error: 'Pending presentation bound exceeded' });
        if (!Number.isSafeInteger(state.serial + 1))
            return result(next, { close, error: 'Retained identity exhausted' });
        const request = Object.freeze({ id: state.serial + 1, key: input.key, deadline: input.now + input.delay, scheduled: false, epoch: state.epoch }), pending = Object.freeze([...state.pending, request]);
        return result(Object.freeze({ ...next, serial: request.id, pending, peakPending: Math.max(next.peakPending, pending.length) }), { close, request });
    }
    if (input.type === 'schedule') {
        const request = state.pending.find(request => request.key === input.key);
        if (!request || request.scheduled || !state.frames.some(frame => frame.key === input.key))
            return result(state, { accepted: false });
        const scheduled = Object.freeze({ ...request, scheduled: true });
        return result(patch({ pending: Object.freeze(state.pending.map(item => item === request ? scheduled : item)) }), { request: scheduled });
    }
    if (input.type === 'draw') {
        const request = state.pending.find(request => request.id === input.id);
        if (input.epoch !== state.epoch || !request?.scheduled || input.now < request.deadline)
            return result(state, { accepted: false });
        const frame = state.frames.find(frame => frame.key === request.key);
        if (!frame)
            return result(state, { accepted: false, error: 'Scheduled retained frame missing' });
        // Publish the held owner and consume the timer receipt before physical drawing.
        return result(patch({ frames: Object.freeze(state.frames.filter(f => f !== frame)), held: frame, pending: Object.freeze(state.pending.filter(r => r !== request)), drawing: Object.freeze({ id: request.id, frame: frame.id, redraw: false }) }), { close: state.held ? Object.freeze([state.held.id]) : empty, frame: frame.id, request, drawing: request.id });
    }
    if (input.type === 'presented') {
        const drawing = state.drawing;
        if (!drawing || drawing.id !== input.id || input.epoch !== state.epoch || state.held?.id !== drawing.frame)
            return result(state, { accepted: false });
        return result(patch({ drawing: null, position: state.held.key / 1e6, drawn: state.drawn + (drawing.redraw ? 0 : 1), redraws: state.redraws + (drawing.redraw ? 1 : 0) }));
    }
    const missing = state.pending.find(request => input.now - request.deadline > 500);
    return missing ? result(patch({ missing: state.missing + 1 }), { error: `Retained frame ${missing.key} did not arrive` }) : result(state);
}
