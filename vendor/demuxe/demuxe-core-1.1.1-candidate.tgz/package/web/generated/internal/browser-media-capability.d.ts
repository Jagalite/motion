import type { Probe } from './selection.js';
import type { BrowserMediaCapability } from './machine/media-facts.js';
export type { BrowserMediaCapability } from './machine/media-facts.js';
type BrowserQueries = {
    canPlayType: (mime: string) => string;
    isTypeSupported?: (mime: string) => boolean;
};
/** Query the browser for the actual selected streams and the destination of each
 * Native plan before allocating a playback backend. Unknowns remain explicit and
 * must be resolved by preparation/startup; a negative answer excludes the plan. */
export declare function nativeBrowserCapabilities(probe: Probe, aid: string, browser: BrowserQueries): {
    direct: BrowserMediaCapability;
    remux: BrowserMediaCapability;
    flac: BrowserMediaCapability;
    opus: BrowserMediaCapability;
};
