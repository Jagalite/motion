export declare const mobileControlsQuery = "(max-width:600px), (pointer:coarse) and (max-width:960px)";
export type PlayerControlsMode = 'auto' | 'mobile' | 'desktop';
export declare const mobileStyles: string;
