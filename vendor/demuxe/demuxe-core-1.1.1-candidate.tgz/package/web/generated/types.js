// SPDX-License-Identifier: Apache-2.0
export const PLAYBACK_MODES = Object.freeze(['native', 'hybrid', 'software']);
export const PLAYER_EVENTS = Object.freeze(['play', 'playing', 'pause', 'waiting', 'ended', 'timeupdate', 'durationchange', 'seeking', 'seeked', 'volumechange', 'ratechange', 'trackschange', 'capabilitieschange', 'sourcechange', 'statechange', 'error', 'modechange', 'selectionchange']);
