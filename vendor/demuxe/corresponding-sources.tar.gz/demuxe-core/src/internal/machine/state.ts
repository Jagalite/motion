// SPDX-License-Identifier: Apache-2.0
import {initialTrackConfirmation,type TrackConfirmationState} from './track-confirmation.js';
import {initialPlayerTransport,type PlayerTransportState} from './player-transport.js';
import {createEffectRuntimeState,type EffectRuntimeState} from './effect-runtime.js';
import {createResourceLedger,type ResourceLedgerState} from './resource-ledger.js';
import {initialPlayerReadiness,type PlayerReadinessState} from './player-readiness.js';
import {initialPlayerActions,type PlayerActionState} from './player-actions.js';
import {initialPlayerPublication,type PlayerPublicationState} from './player-publication.js';
import {initialPlayerMonitor,type PlayerMonitorState} from './player-monitor.js';
import {initialOperations,type OperationState} from './operations.js';
import {initialPlayback,type PlaybackControl} from './playback.js';
import {initialSettings,initialPreferences,initialSettingsTransactions,type PlaybackSettings,type PlayerPreferences,type SettingsTransactions} from './settings.js';
import {initialBoundary,type BoundaryState} from './playback-boundary.js';
import {initialSource,type SourceControl} from './source.js';
import {initialAttachments,type AttachmentState} from './attachments.js';
import {initialRouting,type RoutingState} from './route-state.js';
/** One authoritative composed state reference per Player. Domain reducers have
 * no stores or scheduling of their own. Additional domains join this boundary. */
export type PlayerControlState=Readonly<{revision:number;captureRevision:number;transport:PlayerTransportState;trackConfirmation:TrackConfirmationState;resources:ResourceLedgerState;executor:EffectRuntimeState;readiness:PlayerReadinessState;actions:PlayerActionState;publication:PlayerPublicationState;monitor:PlayerMonitorState;attachments:AttachmentState;routing:RoutingState;boundary:BoundaryState;operations:OperationState;playback:PlaybackControl;settings:Readonly<PlaybackSettings>;preferences:PlayerPreferences;settingsTransactions:SettingsTransactions;source:SourceControl}>;
export function initialPlayerControl():PlayerControlState{return Object.freeze({revision:0,captureRevision:0,transport:initialPlayerTransport(),trackConfirmation:initialTrackConfirmation(),resources:createResourceLedger({monotonic:true}),executor:createEffectRuntimeState(64),readiness:initialPlayerReadiness(),actions:initialPlayerActions(),publication:initialPlayerPublication(),monitor:initialPlayerMonitor(),attachments:initialAttachments(),routing:initialRouting(),boundary:initialBoundary(),operations:initialOperations(),playback:initialPlayback(),settings:initialSettings(),preferences:initialPreferences(),settingsTransactions:initialSettingsTransactions(),source:initialSource()});}
