// SPDX-License-Identifier: Apache-2.0
export type CoopContinuation=Readonly<{phase:'fresh'|'running'|'unwinding'|'suspended'|'rewinding'|'rewind-stopping';site:string|null}>;
export type CoopContinuationStats=Readonly<{maxSavedBytes:number;unwinds:number;rewinds:number}>;
export type CoopTask=Readonly<{continuation:CoopContinuation;id:number;slot:number|null;status:'new'|'running'|'waiting'|'ready'|'done';root:boolean;detached:boolean;joined:boolean}>;
export type CoopWait=Readonly<{id:number;task:number;key:number|null;deadline:number|null;join:number|null}>;
export type CoopStats=Readonly<{created:number;completed:number;abandoned:number;suspensions:number;resumes:number;maxLive:number;timerWakes:number;signals:number;stackChecks:number}>;
export type CoopState=Readonly<{backend:'jspi'|'asyncify';continuations:CoopContinuationStats;attachment:'unattached'|'attaching'|'attached';slots:number;maxRetainedTasks:number;nextId:number;nextWait:number;tasks:readonly CoopTask[];waits:readonly CoopWait[];ready:readonly number[];free:readonly number[];active:number|null;pendingPump:boolean;decoderWake:'idle'|'scheduled'|'running';stopped:boolean;stats:CoopStats}>;
export function initialCoopState(slots=24,maxRetainedTasks=256,backend:'jspi'|'asyncify'='jspi'):CoopState{return Object.freeze({backend,continuations:Object.freeze({maxSavedBytes:0,unwinds:0,rewinds:0}),attachment:'unattached',slots,maxRetainedTasks,nextId:1,nextWait:1,tasks:Object.freeze([]),waits:Object.freeze([]),ready:Object.freeze([]),free:Object.freeze(Array.from({length:slots},(_,index)=>index)),active:null,pendingPump:false,decoderWake:'idle',stopped:false,stats:Object.freeze({created:0,completed:0,abandoned:0,suspensions:0,resumes:0,maxLive:0,timerWakes:0,signals:0,stackChecks:0})});}
export function coopTask(state:CoopState,id:number):CoopTask|undefined{return state.tasks.find(task=>task.id===id);}
export function coopCanCreate(state:CoopState):boolean{return !state.stopped&&state.free.length>0&&state.tasks.length<state.maxRetainedTasks&&state.nextId<=0xffffffff;}
export function createCoopTask(state:CoopState,root:boolean):Readonly<{state:CoopState;task:CoopTask|null}>{
 if(state.attachment!=='attached'||!coopCanCreate(state))return Object.freeze({state,task:null});
 const task=Object.freeze({continuation:Object.freeze({phase:'fresh' as const,site:null}),id:state.nextId,slot:state.free[state.free.length-1],status:'new' as const,root,detached:false,joined:false});
 return Object.freeze({state:Object.freeze({...state,nextId:task.id+1,tasks:Object.freeze([...state.tasks,task]),ready:Object.freeze([...state.ready,task.id]),free:Object.freeze(state.free.slice(0,-1)),stats:Object.freeze({...state.stats,created:state.stats.created+1,maxLive:Math.max(state.stats.maxLive,state.tasks.filter(task=>task.status!=='done').length+1)})}),task});
}
export function scheduleCoopPump(state:CoopState):Readonly<{state:CoopState;send:boolean}>{return state.pendingPump||state.stopped?Object.freeze({state,send:false}):Object.freeze({state:Object.freeze({...state,pendingPump:true}),send:true});}
export function consumeCoopPump(state:CoopState):CoopState{return state.pendingPump?Object.freeze({...state,pendingPump:false}):state;}
export function startCoopTask(state:CoopState):Readonly<{state:CoopState;id:number|null;fresh:boolean}>{
 if(state.active!==null||state.stopped)return Object.freeze({state,id:null,fresh:false});
 const index=state.ready.findIndex(id=>{const task=coopTask(state,id);return task?.status==='new'||task?.status==='ready';});
 if(index<0)return Object.freeze({state:state.ready.length?Object.freeze({...state,ready:Object.freeze([])}):state,id:null,fresh:false});
 const id=state.ready[index],fresh=coopTask(state,id)!.status==='new';
 return Object.freeze({state:Object.freeze({...state,active:id,ready:Object.freeze(state.ready.slice(index+1)),tasks:Object.freeze(state.tasks.map(task=>task.id===id?Object.freeze({...task,status:'running' as const}):task)),stats:fresh?state.stats:Object.freeze({...state.stats,resumes:state.stats.resumes+1})}),id,fresh});
}
export function parkCoopTask(state:CoopState):Readonly<{state:CoopState;wait:CoopWait|null}>{
 const task=state.active===null?undefined:coopTask(state,state.active);
 if(state.stopped||!task||task.status!=='running'||task.continuation.phase!=='running')return Object.freeze({state,wait:null});
 const wait=Object.freeze({id:state.nextWait,task:task.id,key:null,deadline:null,join:null});
 return Object.freeze({state:Object.freeze({...state,nextWait:wait.id+1,waits:Object.freeze([...state.waits,wait]),tasks:Object.freeze(state.tasks.map(item=>item.id===task.id?Object.freeze({...item,status:'waiting' as const}):item)),stats:Object.freeze({...state.stats,suspensions:state.stats.suspensions+1})}),wait});
}
export function bindCoopWait(state:CoopState,id:number,policy:Readonly<{key?:number;deadline?:number|null;join?:number}>):CoopState{
 if(state.stopped||!state.waits.some(wait=>wait.id===id))return state;
 return Object.freeze({...state,waits:Object.freeze(state.waits.map(wait=>wait.id===id?Object.freeze({...wait,...policy.key===undefined?{}:{key:policy.key},...policy.deadline===undefined?{}:{deadline:policy.deadline},...policy.join===undefined?{}:{join:policy.join}}):wait))});
}
export function releaseCoopTask(state:CoopState,id:number):Readonly<{state:CoopState;accepted:boolean}>{
 const task=coopTask(state,id);
 if(state.stopped||state.active!==id||!task||!['waiting','ready'].includes(task.status)||task.continuation.phase!=='suspended')return Object.freeze({state,accepted:false});
 return Object.freeze({state:Object.freeze({...state,active:null}),accepted:true});
}
export function settleCoopWait(state:CoopState,id:number,kind:'ready'|'signal'|'timeout'='ready',now?:number):Readonly<{state:CoopState;accepted:boolean;task:number|null;remove:number|null;remaining:number|null;invalid:boolean}>{
 const wait=state.waits.find(wait=>wait.id===id),empty={state,accepted:false,task:null,remove:null,remaining:null,invalid:false};
 if(!wait||state.stopped)return Object.freeze(empty);
 if(wait.join!==null&&coopTask(state,wait.join)?.status!=='done')return Object.freeze(empty);
 if(kind==='timeout'&&(now===undefined||wait.deadline===null))return Object.freeze(empty);
 if(kind==='timeout'&&now!==undefined&&wait.deadline!==null&&now<wait.deadline)return Object.freeze({...empty,remaining:wait.deadline-now});
 const task=coopTask(state,wait.task);if(task?.status!=='waiting')return Object.freeze({...empty,invalid:true});
 return Object.freeze({state:Object.freeze({...state,waits:Object.freeze(state.waits.filter(item=>item.id!==id)),tasks:Object.freeze(state.tasks.filter(item=>item.id!==wait.join).map(item=>item.id===task.id?Object.freeze({...item,status:'ready' as const}):item)),ready:Object.freeze([...state.ready,task.id]),stats:Object.freeze({...state.stats,timerWakes:state.stats.timerWakes+(kind==='timeout'?1:0),signals:state.stats.signals+(kind==='signal'?1:0)})}),accepted:true,task:task.id,remove:wait.join,remaining:null,invalid:false});
}
export function coopConditionWaits(state:CoopState,key:number,all:boolean):readonly number[]{const ids=state.waits.filter(wait=>wait.key===key).map(wait=>wait.id);return Object.freeze(all?ids:ids.slice(0,1));}
export function prepareCoopJoin(state:CoopState,id:number):Readonly<{state:CoopState;code:number;wait:boolean;remove:boolean}>{
 const task=coopTask(state,id);if(!task||task.root||task.detached||task.joined)return Object.freeze({state,code:1,wait:false,remove:false});
 if(task.id===state.active)return Object.freeze({state,code:2,wait:false,remove:false});
 const done=task.status==='done';return Object.freeze({state:Object.freeze({...state,tasks:Object.freeze(done?state.tasks.filter(item=>item.id!==id):state.tasks.map(item=>item.id===id?Object.freeze({...item,joined:true}):item))}),code:0,wait:!done,remove:done});
}
export function detachCoopTask(state:CoopState,id:number):Readonly<{state:CoopState;code:number;remove:boolean}>{
 const task=coopTask(state,id);if(!task||task.root||task.detached||task.joined)return Object.freeze({state,code:1,remove:false});
 const done=task.status==='done';return Object.freeze({state:Object.freeze({...state,tasks:Object.freeze(done?state.tasks.filter(item=>item.id!==id):state.tasks.map(item=>item.id===id?Object.freeze({...item,detached:true}):item))}),code:0,remove:done});
}
export function completeCoopTask(state:CoopState,id:number):Readonly<{state:CoopState;accepted:boolean;wake:readonly number[];remove:readonly number[]}>{
 const task=coopTask(state,id),empty={state,accepted:false,wake:Object.freeze([]) as readonly number[],remove:Object.freeze([]) as readonly number[]};
 if(state.stopped||state.active!==id||!task||task.status!=='running'||task.continuation.phase!=='running'||task.slot===null)return Object.freeze(empty);
 const remove:number[]=task.root||task.detached?[id]:[],wake=state.waits.filter(wait=>wait.join===id).map(wait=>wait.id);
 let next:CoopState=Object.freeze({...state,active:null,free:Object.freeze([...state.free,task.slot]),tasks:Object.freeze(state.tasks.filter(item=>!remove.includes(item.id)).map(item=>item.id===id?Object.freeze({...item,status:'done' as const,slot:null}):item)),stats:Object.freeze({...state.stats,completed:state.stats.completed+1})});
 for(const wait of wake){const settled=settleCoopWait(next,wait);next=settled.state;if(settled.remove!==null&&!remove.includes(settled.remove))remove.push(settled.remove);}
 return Object.freeze({state:next,accepted:true,wake:Object.freeze(wake),remove:Object.freeze(remove)});
}
export function checkedCoopStack(state:CoopState):CoopState{return state.stopped?state:Object.freeze({...state,stats:Object.freeze({...state.stats,stackChecks:state.stats.stackChecks+1})});}
export function closeCoopState(state:CoopState):CoopState{return state.stopped?state:Object.freeze({...state,stopped:true,pendingPump:false,decoderWake:'idle',active:null,free:Object.freeze([]),ready:Object.freeze([]),waits:Object.freeze([]),tasks:Object.freeze([]),stats:Object.freeze({...state.stats,abandoned:state.stats.abandoned+state.tasks.filter(task=>task.status!=='done').length})});}
export function snapshotCoopState(state:CoopState):Readonly<CoopStats&{liveTasks:number;retainedTasks:number;waitKeys:number;freeSlots:number;stopped:boolean}>{
 const keys:number[]=[];for(const wait of state.waits)if(wait.key!==null&&!keys.includes(wait.key))keys.push(wait.key);
 return Object.freeze({...state.stats,liveTasks:state.tasks.filter(task=>task.status!=='done').length,retainedTasks:state.tasks.length,waitKeys:keys.length,freeSlots:state.free.length,stopped:state.stopped});
}

export function beginCoopAttachment(state:CoopState):Readonly<{state:CoopState;accepted:boolean}>{return state.stopped||state.attachment!=='unattached'?Object.freeze({state,accepted:false}):Object.freeze({state:Object.freeze({...state,attachment:'attaching' as const}),accepted:true});}
export function finishCoopAttachment(state:CoopState):Readonly<{state:CoopState;accepted:boolean}>{return state.stopped||state.attachment!=='attaching'?Object.freeze({state,accepted:false}):Object.freeze({state:Object.freeze({...state,attachment:'attached' as const}),accepted:true});}

export type CoopContinuationInput=
 |Readonly<{type:'begin'|'park'|'unwound'|'resume'|'rewound'|'return';id:number}>
 |Readonly<{type:'site'|'rewind-import';id:number;site:string}>
 |Readonly<{type:'checked';id:number;savedBytes:number}>;
/** Protocol authority shares the scheduler lifetime; all native objects stay in the driver. */
export function transitionCoopContinuation(state:CoopState,input:CoopContinuationInput):Readonly<{state:CoopState;accepted:boolean}>{
 const task=coopTask(state,input.id),no=Object.freeze({state,accepted:false});
 if(state.stopped||state.active!==input.id||!task)return no;
 const current=task.continuation;
 let phase=current.phase,site=current.site,stats=state.continuations;
 switch(input.type){
  case 'begin':if(task.status!=='running'||phase!=='fresh')return no;phase='running';break;
  case 'park':if(task.status!=='waiting'||phase!=='running')return no;phase=state.backend==='asyncify'?'unwinding':'suspended';break;
  case 'site':if(state.backend!=='asyncify'||phase!=='unwinding'||site!==null||!input.site)return no;site=input.site;break;
  case 'unwound':if(state.backend!=='asyncify'||phase!=='unwinding'||site===null)return no;phase='suspended';stats=Object.freeze({...stats,unwinds:stats.unwinds+1});break;
  case 'resume':if(task.status!=='running'||phase!=='suspended'||(state.backend==='asyncify'&&site===null))return no;phase=state.backend==='asyncify'?'rewinding':'running';break;
  case 'rewind-import':if(state.backend!=='asyncify'||phase!=='rewinding'||site!==input.site)return no;phase='rewind-stopping';site=null;break;
  case 'rewound':if(state.backend!=='asyncify'||phase!=='rewind-stopping')return no;phase='running';stats=Object.freeze({...stats,rewinds:stats.rewinds+1});break;
  case 'return':if(task.status!=='running'||phase!=='running')return no;return Object.freeze({state,accepted:true});
  case 'checked':if(state.backend!=='asyncify'||!Number.isSafeInteger(input.savedBytes)||input.savedBytes<0)return no;stats=Object.freeze({...stats,maxSavedBytes:Math.max(stats.maxSavedBytes,input.savedBytes)});break;
 }
 const continuation=phase===current.phase&&site===current.site?current:Object.freeze({phase,site});
 return Object.freeze({state:Object.freeze({...state,continuations:stats,tasks:continuation===current?state.tasks:Object.freeze(state.tasks.map(value=>value.id===input.id?Object.freeze({...value,continuation}):value))}),accepted:true});
}
export function snapshotCoopContinuations(state:CoopState):Readonly<{kind:'jspi'|'asyncify';maxSavedBytes?:number;unwinds?:number;rewinds?:number}>{return state.backend==='jspi'?Object.freeze({kind:state.backend}):Object.freeze({kind:state.backend,...state.continuations});}

export function transitionCoopDecoderWake(state:CoopState,input:'schedule'|'begin'|'finish'):Readonly<{state:CoopState;accepted:boolean}>{
 const phase=input==='schedule'?'scheduled':input==='begin'?'running':'idle';
 const accepted=input==='finish'?state.decoderWake!=='idle':!state.stopped&&state.decoderWake===(input==='schedule'?'idle':'scheduled');
 return Object.freeze({state:accepted?Object.freeze({...state,decoderWake:phase}):state,accepted});
}
