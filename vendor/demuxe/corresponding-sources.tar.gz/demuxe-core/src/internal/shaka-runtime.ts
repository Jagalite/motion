// SPDX-License-Identifier: Apache-2.0
import {bundledShakaIncluded} from './provider-build.js';
import type {Shaka} from './shaka-api.js';
import type {ProviderRuntimeAssets} from './provider-runtime.js';
import {PlayerError,isPlayerError} from './errors.js';
import {createShakaRuntime,joinShakaRuntime,acquireShakaRuntime,releaseShakaRuntimeAcquisition,leaveShakaRuntime,finishShakaRuntime,shakaRuntimeLoad,shakaRuntimeDeadline} from './machine/shaka-runtime.js';

type Handle={promise:Promise<typeof Shaka>;resolve:(runtime:typeof Shaka)=>void;reject:(error:Error)=>void;controller?:AbortController;script?:HTMLScriptElement;blob?:string;timer?:ReturnType<typeof setTimeout>;timerToken?:object};
const aborted=()=>new PlayerError('ABORTED','Shaka runtime loading cancelled');
/** Shared runtime policy has one module lifetime; executable code, promises,
 * script nodes, fetch controllers and object URLs stay in this adapter. */
export class ShakaRuntimeLoader {
 constructor(private readonly providerAssets?:ProviderRuntimeAssets,private readonly bundledIncluded=true){}
 private state=createShakaRuntime();
 private handles=new Map<number,Handle>();
 load(base:URL,signal:AbortSignal):Promise<typeof Shaka>{
  if(signal.aborted)return Promise.reject(aborted());
  if(!this.providerAssets&&!this.bundledIncluded)return Promise.reject(new PlayerError('DEPLOYMENT_UNAVAILABLE','Shaka provider is not included'));
  const url=new URL('web/vendor/shaka-player.js',base).href,now=performance.now(),joined=joinShakaRuntime(this.state,url,now);this.state=joined.state;
  if(!joined.accepted)return Promise.reject(new PlayerError('ASSET_LOAD_FAILED',joined.error));
  const {load,consumer,start}=joined;
  let handle=this.handles.get(load);
  if(start){
   let resolve!:(runtime:typeof Shaka)=>void,reject!:(error:Error)=>void;const promise=new Promise<typeof Shaka>((yes,no)=>{resolve=yes;reject=no;});void promise.catch(()=>{});
   handle={promise,resolve,reject};this.handles.set(load,handle);
  }
  const owned=handle!;
  const result=new Promise<typeof Shaka>((resolve,reject)=>{
   const release=()=>{
    const outcome=leaveShakaRuntime(this.state,load,consumer);this.state=outcome.state;
    if(!outcome.accepted)return false;
    try{signal.removeEventListener('abort',cancel);}catch{}
    if(outcome.cancel)this.cancel(load,owned);
    return true;
   };
   const cancel=()=>{if(release())reject(aborted());};
   try{signal.addEventListener('abort',cancel,{once:true});}catch(error){release();reject(error);}
   if(signal.aborted)cancel();
   owned.promise.then(runtime=>{if(release())resolve(runtime);},error=>{if(release())reject(error);});
  });
  // Install both the shared promise and its first consumer before any fetch,
  // timer or DOM callback can synchronously create another consumer or retire it.
  if(start&&this.current(load))this.start(load,owned,url);
  return result;
 }
 private current(id:number){return shakaRuntimeLoad(this.state,id)?.phase==='pending';}
 private cleanup(handle:Handle,abort:boolean){
  const timer=handle.timer,script=handle.script,blob=handle.blob,controller=handle.controller;
  handle.timer=undefined;handle.timerToken=undefined;handle.script=undefined;handle.blob=undefined;
  const tasks=[()=>{if(timer!==undefined)clearTimeout(timer);},()=>{if(script)script.onload=null;},()=>{if(script)script.onerror=null;},()=>{script?.remove();},()=>{if(blob)URL.revokeObjectURL(blob);},()=>{if(abort)controller?.abort();}];
  for(const task of tasks)try{task();}catch{/* Finish every owned release before settling consumers. */}
 }
 private cancel(id:number,handle:Handle){if(!shakaRuntimeLoad(this.state,id))this.handles.delete(id);this.cleanup(handle,true);handle.reject(aborted());}
 private finish(id:number,handle:Handle,error?:Error,runtime?:typeof Shaka){
  const result=finishShakaRuntime(this.state,id,!error);this.state=result.state;if(!result.accepted)return;
  if(error&&!shakaRuntimeLoad(this.state,id)?.acquiring)this.handles.delete(id);this.cleanup(handle,!!error);
  if(error)handle.reject(error);else handle.resolve(runtime!);
 }
 private deadline(id:number,handle:Handle,delay:number){
  const token={};handle.timerToken=token;
  try{
   const timer=setTimeout(()=>{
    if(handle.timerToken!==token)return;handle.timer=undefined;handle.timerToken=undefined;
    const now=performance.now(),next=shakaRuntimeDeadline(this.state,id,now);
    if(!next.current)return;
    if(next.remaining>0)this.deadline(id,handle,next.remaining);else this.finish(id,handle,new PlayerError('ASSET_LOAD_FAILED','Shaka runtime loading timed out'));
   },delay);
   if(handle.timerToken===token)handle.timer=timer;else clearTimeout(timer);
  }catch{this.finish(id,handle,new PlayerError('ASSET_LOAD_FAILED','Shaka runtime loading failed'));}
 }
 private start(id:number,handle:Handle,url:string){
  try{handle.controller=new AbortController();if(!this.current(id)){handle.controller.abort();return;}this.deadline(id,handle,15000);}catch{this.finish(id,handle,new PlayerError('ASSET_LOAD_FAILED','Shaka runtime loading failed'));return;}
  if(!this.current(id))return;
  this.state=acquireShakaRuntime(this.state,id);
  void(async()=>{
   let code:string;
   if(this.providerAssets){
    code=new TextDecoder().decode(await this.providerAssets.bytes('web/vendor/shaka-player.js'));
   }else{
    const response=await fetch(url,{signal:handle.controller!.signal,credentials:'same-origin',redirect:'error'});
    if(!this.current(id)){try{await response.body?.cancel();}catch{}return;}
    if(!response.ok)throw Error('Shaka asset response failed');
    code=await response.text();
   }
   if(!this.current(id))return;
   const blob=URL.createObjectURL(new Blob(['if(document.currentScript?.isConnected){\n',code,'\n}'],{type:'text/javascript'}));
   if(!this.current(id)){try{URL.revokeObjectURL(blob);}catch{}return;}handle.blob=blob;
   const script=document.createElement('script');
   if(!this.current(id)){try{script.remove();}catch{}return;}handle.script=script;
   script.src=blob;script.async=true;
   script.onload=()=>{if(!this.current(id))return;const runtime=(globalThis as unknown as {shaka?:typeof Shaka}).shaka;this.finish(id,handle,runtime?.Player?undefined:new PlayerError('ASSET_LOAD_FAILED','Shaka runtime is unavailable'),runtime);};
   script.onerror=()=>this.finish(id,handle,new PlayerError('ASSET_LOAD_FAILED','Shaka runtime execution failed'));
   if(this.current(id)){document.head.append(script);if(!this.current(id))try{script.remove();}catch{}}
  })().catch(error=>this.finish(id,handle,isPlayerError(error)?error:new PlayerError('ASSET_LOAD_FAILED','Shaka runtime loading failed'))).finally(()=>{this.state=releaseShakaRuntimeAcquisition(this.state,id);if(shakaRuntimeLoad(this.state,id)?.phase!=='ready'&&!this.current(id))this.handles.delete(id);});
 }
}
const shared=new ShakaRuntimeLoader(undefined,bundledShakaIncluded);
// Keep caches within the deployment that verified the executable bytes.
const deployed=new WeakMap<ProviderRuntimeAssets,ShakaRuntimeLoader>();
export function runtimeAt(base:URL,signal:AbortSignal,assets?:ProviderRuntimeAssets):Promise<typeof Shaka>{
 if(!assets)return shared.load(base,signal);
 let loader=deployed.get(assets);if(!loader){loader=new ShakaRuntimeLoader(assets);deployed.set(assets,loader);}
 return loader.load(base,signal);
}
